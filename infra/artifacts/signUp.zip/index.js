"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("@lumiere/shared");
var SignUpAction;
(function (SignUpAction) {
    SignUpAction["CREATE"] = "create";
    SignUpAction["CONFIRM"] = "confirm";
})(SignUpAction || (SignUpAction = {}));
const logger = (0, shared_1.createAppLogger)('SignUpFunction');
const clientId = process.env.AUTH_CLIENT_ID;
const clientSecret = process.env.AUTH_CLIENT_SECRET;
const handler = async (event) => {
    logger.debug('Received sign-up request', { eventType: 'SignUpAttempt', details: { event } });
    try {
        const body = JSON.parse(event.body || '{}');
        const action = event.pathParameters?.action ?? null;
        const authService = new shared_1.AuthService(clientId, clientSecret);
        const strategies = {
            [SignUpAction.CREATE]: () => authService.signUpUser(body.username, body.password),
            [SignUpAction.CONFIRM]: () => authService.confirmSignUp(body.username, body.verifyCode),
        };
        handleValidation(body, action);
        await strategies[action]();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User signed up successfully' }),
        };
    }
    catch (error) {
        const exception = (error instanceof shared_1.BaseException) ? error : new shared_1.UnexpectedErrorException(String(error));
        const { message, name, reason, statusCode, stack } = exception;
        logger.error(message, { eventType: name, reason, stack });
        return {
            statusCode: statusCode,
            body: JSON.stringify({ message, errorCode: name }),
        };
    }
};
exports.handler = handler;
const handleValidation = (payload, action) => {
    const { username, password, verifyCode } = payload;
    if (!action) {
        throw new shared_1.InvalidInputException(`URL pathParam for SignUp is missing or invalid. (expected: auth/sign-up/{create|confirm}`);
    }
    const validationStrategies = {
        [SignUpAction.CREATE]: () => {
            if (!username || !password) {
                throw new shared_1.InvalidInputException(`Username and password are required for sign-up creation. 
         username received: ${!!username}, password received : ${!!password}`);
            }
        },
        [SignUpAction.CONFIRM]: () => {
            if (!username || !verifyCode) {
                throw new shared_1.InvalidInputException(`Username and verification code are required for sign-up confirmation. 
        username received: ${!!username}, verifyCode received: ${!!verifyCode}`);
            }
        },
    };
    validationStrategies[action]();
};
